# MullenCreates Style Guide

This repository contains the global style guide for MullenCreates.com, including:

- Brand color palette
- Typography system
- Reusable UI components
- WordPress styling overrides
- Blocks used in public-facing dashboards
